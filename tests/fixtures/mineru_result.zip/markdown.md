## Service Agreement

Article 1. Purpose

This agreement defines the terms of the cloud storage service.

## Article 5. Termination

Either party may terminate with 30 days written notice.